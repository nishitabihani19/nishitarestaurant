
<html>
   <head>
    <link rel="stylesheet" type="text/css" href="login.css">
	<!-- TITLE AND FAVICON-->
	<title>Nishita's Restaurant</title>
	<link rel="shortcut icon" href="images/logo.png">
	<!-- *END* TITLE AND FAVICON-->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- BOOTSTRAP ONLINE LINK/ RESPONSIVE WEBPAGE-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Font awesome link-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Font awesome link-->
  	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  	<!-- *END* BOOTSTRAP ONLINE LINK/ RESPONSIVE WEBPAGE-->
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="index.html">
    <img src="images/logo.png" alt="Logo" style="width:40px; height: 40px;">Nishita's Restaurant
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  	<div class="nav-container">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item">
        <a class="nav-link" href="home.html"><i class="fa fa-home"></i> Home</a>
    </li>
       <li class="nav-item">
        <a class="nav-link" href="features.html"><i class="fa fa-cogs"></i> Features</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="login1.php"><i class="fa fa-edit"></i> Login</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="order.html"><i class="fa fa-search"></i> order</a>
      </li>    <li class="nav-item">
        <a class="nav-link"  href="https://www.google.com/maps/place/Mansarovar+Plaza,+Ward+27,+Agarwal+Farm,+Barh+Devariya,+Mansarovar,+Jaipur,+Rajasthan+302020/@26.8549298,75.763296,17z/data=!4m8!1m2!2m1!1sRestaurants!3m4!1s0x396db5a42595f835:0x8c29f103bc2827bd!8m2!3d26.8546382!4d75.7667191"><i class="fa fa-car"></i>Maps </a>
      </li>
    </ul>
</div>

  </div>
</nav>
<div class="collapse" id="search">
  <div class="card card-body">
 <form class="search-form">
 	<div class="form-group">
 	<input class="search" type="text" name="search" placeholder="Enter your text here...">
 	<input class="btn-info" type="submit" name="submit-search" placeholder="Submit">
 	</div>
 </form>
  </div>
</div>
            <h1><center>Admin Page</center></h1><hr>
 <div class="boxed">
<div id="containe">   
    <form method="POST" action="in.html">
    <h3>Add Dish</h3>
<input class="text" name="id" placeholder="Enter Item ">
               <input class="submit" type="submit" name="submit" value="submit">
    </form>
       <h2 style="color:black;">Search user:</h2><form method="POST" action="adminshow.php"><input class="text" name="email" placeholder="Enter Email" required><input class="submit" type="submit" name="submit" value="Search"></form><br>
        <hr>
        
     </div>
    </div>
    <hr>
    
    </body>
</html>