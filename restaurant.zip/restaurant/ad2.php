<?php
$a=$_POST['additem'];

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<select>others
            <option><?php echo "$a"; ?></option>
                
        </select>

</body>
</html>