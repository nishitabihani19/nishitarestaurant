
<html>
    <head>   <link rel="stylesheet" type="text/css" href="login.css">
	<!-- TITLE AND FAVICON-->
	<title>Nishita's Restaurant</title>
	<link rel="shortcut icon" href="images/logo.png">
	<!-- *END* TITLE AND FAVICON-->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- BOOTSTRAP ONLINE LINK/ RESPONSIVE WEBPAGE-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Font awesome link-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Font awesome link-->
  	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  	<!-- *END* BOOTSTRAP ONLINE LINK/ RESPONSIVE WEBPAGE-->
<body>
       <nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="index.html">
    <img src="images/logo.png" alt="Logo" style="width:40px; height: 40px;">Nishita's Restaurant
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  	<div class="nav-container">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item">
        <a class="nav-link" href="home.html"><i class="fa fa-home"></i> Home</a>
    </li>
       <li class="nav-item">
        <a class="nav-link" href="features.html"><i class="fa fa-cogs"></i> Features</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="login.html"><i class="fa fa-edit"></i> Login</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#search"><i class="fa fa-search"></i> Search</a>
      </li>
    </ul>
</div>

  </div>
</nav>
<div class="collapse" id="search">
  <div class="card card-body">
 <form class="search-form">
 	<div class="form-group">
 	<input class="search" type="text" name="search" placeholder="Enter your text here...">
 	<input class="btn-info" type="submit" name="submit-search" placeholder="Submit">
 	</div>
 </form>
  </div>
</div>
        <div class="boxed">
    <form method="POST" action="checkout.php">

        <h4>
      <input class="text" name="nam1" placeholder="Name"required><br><br>
          <input class="text" name="nam3" placeholder="Email" required><br><br>
        <input class="text" type="number" name="nam5" placeholder="Mobile no." required><br><br>
            <input class="text" type="text" name="address" placeholder="Address" required><br><br>
           <input class="text" type="pincode" name="pincode" placeholder="Pincode" required><br><br> 
              <input class="submit" type="submit" name="submit" value="Order">
        </h4>  </form>
            </div></div>
    </body></html>