<?php
$c=$_POST['nam1'];
$d=$_POST['nam3'];
$e=$_POST['nam5'];
$f=$_POST['address'];
$g=$_POST['pincode'];
$_SESSION['nam5']=$e;
$servername="localhost";
$username="root";
$password="";
$dbname="contact";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("connection failed:".mysqli_connect_error());
}
else
{
	$sql="insert into `record`( `name`,`email`,`mobileno`,`address`,`pincode`) values('$c','$d','$e','$f','$g');";
	$var=mysqli_query($conn,$sql);
	if($var)
	{
		
    echo "<script>
        window.location.href='msg.php'</script>";

	}
	else
	{
		echo "Error:".$sql."<br>".mysqli_error($conn);
	}
}
mysqli_close($conn);
?>