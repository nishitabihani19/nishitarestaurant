<?php
session_start();
$a=$_SESSION['nam5'];
$mobile="$a";
$message="Thankyou,your order is successfully placed.Feel free call Nishta Bihani(6350386531) for help.";
$json = json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=6350386531&Password=nishita12345&Message=".urlencode($message)."&To=".urlencode($mobile)."&Key=nishixpzvJyU9CPkAVSs4K") ,true);
if ($json["status"]==="success") {
    echo "<script>
        window.location.href='index.php'</script>";
    //your code when send success
}else{
   echo "<script>
        window.location.href='index.php'</script>";
    //your code when not send
}
?>
     