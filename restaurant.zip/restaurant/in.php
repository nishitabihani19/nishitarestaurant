<?php
$a=$_POST['additem'];

?>

<!DOCTYPE html>
<html>
<head>
        <title>Menu</title>    
    <link rel="stylesheet" type="text/css" href="a.css">
    <!-- TITLE AND FAVICON-->
	<title>Nishita's Restaurant</title>
	<link rel="shortcut icon" href="images/logo.png">
	<!-- *END* TITLE AND FAVICON-->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- BOOTSTRAP ONLINE LINK/ RESPONSIVE WEBPAGE-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Font awesome link-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Font awesome link-->
  	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  	<!-- *END* BOOTSTRAP ONLINE LINK/ RESPONSIVE WEBPAGE-->
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="index.html">
    <img src="images/logo.png" alt="Logo" style="width:40px; height: 40px;">Nishita's Restaurant
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  	<div class="nav-container">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item">
        <a class="nav-link" href="home.html"><i class="fa fa-home"></i> Home</a>
    </li>
       <li class="nav-item">
        <a class="nav-link" href="features.html"><i class="fa fa-cogs"></i> Features</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="login1.php"><i class="fa fa-edit"></i> Login</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="order.html"><i class="fa fa-search"></i> Order</a>
      </li>
        <li class="nav-item">
        <a class="nav-link"  href="piechart.html"><i class="fa fa-cogs"></i>Details </a>
      </li>
    
    </ul>
</div>

  </div>
</nav>
<div class="collapse" id="search">
  <div class="card card-body">
 <form class="search-form">
 	<div class="form-group">
 	<input class="search" type="text" name="search" placeholder="Enter your text here...">
 	<input class="btn-info" type="submit" name="submit-search" placeholder="Submit">
 	</div>
 </form>
  </div>
</div>
    <center>
    <div class="boxed"><form method="POST" action="data.php">
        <div class="main">
    <div id="mainselection">
<select>
        <option>Starters</option>
            <option>Aloo tikka</option>
                <option>Paneer Tikka</option>
                <option>Chilly Potato</option>
                <option>Paneer Taka Tak</option>
                <option>Garlic Chilly Potato</option>
                <option>Honey Chilly Potato</option>
                <option>Paneer Tikka</option>
                <option>Tandoori Aloo</option>
        </select><br>
    </div>  <div id="mainselection">
        <select>
                <option>Quick Bites</option>
                <option>Veg Roll</option>
                <option>Chowmien Roll</option>
                <option>Cheese Roll</option>
                <option>Paneer Roll</option>
                <option>Bhel Puri</option>
                <option>French Fries</option>
                <option>Nachos with Salsa</option>
                <option>Masala Cheese Maggi</option>
    </select><br></div>
  <div id="mainselection"><select>
                <option>Chinese Delicacies</option>
                <option>Chilly Panner</option>
                <option>Manchurian Gravy</option>
                <option>Manchurian Dry</option>
                <option>Steamed Momos</option>
                <option>Fried Momos</option>
                <option>Deep Fried Momos</option>
                <option>Tandoori Momos</option>
      </select><br></div>
  <div id="mainselection"><select>
                <option>Pizza and Pasta</option>
                <option>Special Pizza</option>
                <option>Onion Pizza</option>
                <option>Cheese Pizza</option>
                <option>OTC Pizza</option>
                <option>Corn Pizza</option>
                <option>Peppy Pizza</option>
                <option>Pink Sauce pasta</option>
                <option>Alfredo Pasta</option>
      </select><br></div>
  <div id="mainselection"><select>
                <option>Sandwiches & Burger</option>
                <option>Aloo Tikki Burger</option>
                <option>Cheese Slice Burger</option>
                <option>Paneer Burger</option>
                <option>Double Daker Burger</option>
                <option>Spicy Cheese Burger</option>
                <option>Cheese Sandwich</option>
                <option>Corn Sandwich</option>
                <option>Garlic Sandwich</option>
      </select><br></div>
  <div id="mainselection"><select>
                <option>Shakes</option>
                <option>Vanilla Shake</option>
                <option>Chocolate Shake</option>
                <option>Kitkat Shake</option>
                <option>Strawberry Shake</option>
                <option>Oreo Shake</option>
                <option>Brownie Shake</option>
                <option>Papaya Shake</option>
                <option>Banana Shake</option>
      </select><br></div>
  <div id="mainselection"><select>
                <option>Main Course</option>
                <option>Kadhai Paneer</option>
                <option>Jeersa Paneer</option>
                <option>Paneer Pyaaz</option>
                <option>Matar Paneer</option>
                <option>Shahi Paneer</option>
                <option>Paneer Butter Masala</option>
                <option>Malai Kofte</option>
                <option>Panner Korma</option>
      </select><br></div>
  <div id="mainselection"><select>
                <option>Dessert & Beverages</option>
                <option>Hot Coffee</option>
                <option>Cold Coffee</option>
                <option>Cold Coffee with Vanilla Ice Cream</option>
                <option>Cold Coffee with strawberry Ice Cream</option>
                <option>Cold Coffee with Butter-Scoach Ice Cream</option>
                <option>Cold Coffee with Choco Chips</option>
                <option>Cold Coffee with Kesar-Pista Ice Cream</option>
                <option>Cold Coffee with Dark Chocolate</option>
                <option>Cold Coffee with Vanilla & Choco Chips</option>
                <option>Nishita's Special Cold Coffee</option>
      </select></div>
        <div id="mainselection"><select>
                <option>others</option>
                <option> <?php echo "$a"; ?></option>
                
      </select></div>
        </div></form></div></center>
</body>
</html>
