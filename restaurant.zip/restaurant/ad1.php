<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST" action="in.php">
		<input type="text" name="additem" id="additem" placeholder="add the item">
		<input type="submit" name="">
	</form>

</body>
</html>