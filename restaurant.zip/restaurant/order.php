<?php
$a=$_POST['orders1'];
$b=$_POST['orders2'];
$c=$_POST['orders3'];
$d=$_POST['orders4'];
$e=$_POST['orders5'];
$f=$_POST['orders6'];
$g=$_POST['orders7'];
$h=$_POST['orders8'];
$servername="localhost";
$username="root";
$password="";
$dbname="contact";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
  die("connection failed:".mysqli_connect_error());
}
else
{
  $sql="insert into `orderdata`(`order1`,`order2`,`order3`,`order4`,`order5`,`order6`,`order7`,`order8`) values('$a','$b','$c','$d','$e','$f','$g','$h');";
  $var=mysqli_query($conn,$sql);
  if($var)
  {

     echo "<script>
        window.location.href='userinfo.php'</script>";
  }
  else
  {
    echo "Error:".$sql."<br>".mysqli_error($conn);
  }
}
mysqli_close($conn);
?>
?>