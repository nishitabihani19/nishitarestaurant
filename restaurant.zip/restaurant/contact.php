<?php
$a=$_POST['name'];
$b=$_POST['email'];
$c=$_POST['comment'];
$servername="localhost";
$username="root";
$password="";
$dbname="contact";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
  die("connection failed:".mysqli_connect_error());
}
else
{
  $sql="insert into `contact`(`name`,`email`,`comment`) values('$a','$b','$c');";
  $var=mysqli_query($conn,$sql);
  if($var)
  {
     echo "<script>alert('Thankyou for feedback');
        window.location.href='index.html'</script>";
  
  }
  else
  {
    echo "Error:".$sql."<br>".mysqli_error($conn);
  }
}
mysqli_close($conn);
?>